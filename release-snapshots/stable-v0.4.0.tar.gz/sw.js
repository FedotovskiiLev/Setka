const PREFIX='setka-';
const CACHE=PREFIX+'ccfbc73b184739d2';
const FILES=["./","./app.js","./assets/icon-192.png","./assets/icon-512.png","./assets/icon.svg","./data/catalog.json","./data/workbooks/mipt-192b74a3774ec7da-3354bb93705e709e.xlsx","./data/workbooks/mipt-192b74a3774ec7da-898b7489542efc4c.xlsx","./data/workbooks/mipt-32b7b890afb5eee4-d55f93488d1e45e2.xls","./data/workbooks/mipt-417c483909021295-046e1c9798d4dbe6.xls","./data/workbooks/mipt-417c483909021295-14e075293c19602d.xls","./data/workbooks/mipt-70716429b751b00e-2fee9c5c3f59f293.xls","./data/workbooks/mipt-70716429b751b00e-8f4261545a797ca3.xls","./data/workbooks/mipt-d22c69cdb4e92dad-03168d535d282e1d.xls","./data/workbooks/mipt-d22c69cdb4e92dad-acf280952ba4eefc.xls","./data/workbooks/mipt-d2d1adf1e5b93076-37096429e76de801.xls","./data/workbooks/mipt-d2d1adf1e5b93076-3f06234d62354c64.xls","./data/workbooks/mipt-d70960a4648db112-98dd4de87b0f6fed.xls","./data/workbooks/mipt-de5ba22b48a28779-b922e54f5d246d2c.xlsx","./data/workbooks/mipt-de5ba22b48a28779-cf8146f688bd0641.xlsx","./fixtures/mipt/File.xlsx","./index.html","./manifest.webmanifest","./src/styles.css","./src/workspace.css","./vendor/JSZip-LICENSE.md","./vendor/README.md","./vendor/SheetJS-LICENSE.txt","./vendor/cpexcel.full.mjs","./vendor/jszip.min.js","./vendor/xlsx.mjs"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
  const url=new URL(event.request.url);
  if(!url.href.startsWith(self.registration.scope))return;
  // The root Stable worker must leave child installations to their own workers.
  if(PREFIX==='setka-'&&['unstable/','betha/'].some(path=>url.href.startsWith(new URL(path,self.registration.scope).href)))return;
  // A cached catalog must never masquerade as a fresh source check.
  if(url.pathname.endsWith('/data/catalog.json')){event.respondWith(fetch(event.request));return;}
  event.respondWith(fetch(event.request).catch(async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(event.request,{ignoreSearch:true});
    return cached||(event.request.mode==='navigate'?await cache.match(new URL('./',self.registration.scope)):new Response('Offline',{status:503}));
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();const data=event.notification.data||{};
  event.waitUntil((async()=>{const windows=await clients.matchAll({type:'window',includeUncontrolled:true});const existing=windows.find(w=>w.url.startsWith(self.registration.scope));if(existing){await existing.focus();existing.postMessage({type:'notification-open',...data});}else{const url=new URL('./',self.registration.scope);url.searchParams.set('view',data.view||'today');if(data.date)url.searchParams.set('date',data.date);await clients.openWindow(url.href);}})());
});
